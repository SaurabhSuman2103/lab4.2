import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-phone',
  templateUrl: './basic-phone.component.html',
  styleUrls: ['./basic-phone.component.css']
})
export class BasicPhoneComponent implements OnInit {
  mobileType:string="BasicPhone"

  constructor() { }

  ngOnInit() {
  }

}
