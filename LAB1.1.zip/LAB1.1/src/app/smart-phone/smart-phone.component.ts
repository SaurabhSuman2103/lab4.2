import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smart-phone',
  templateUrl: './smart-phone.component.html',
  styleUrls: ['./smart-phone.component.css']
})
export class SmartPhoneComponent implements OnInit {
  mobileType:string="SmartPhone";
  constructor() { }

  ngOnInit() {
  }

}
