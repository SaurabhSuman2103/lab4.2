import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { BookDataService } from './book-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ComponentInteraction';

  jsonString;

  bookListTemp;

  
  constructor(private ob:BookDataService){}

  ngOnInit(){
    this.ob.getData().subscribe(data =>{this.bookListTemp = data;this.jsonString=JSON.stringify(data);});
  }
  
  filterSearch(colName,filterValue){
    this.bookListTemp = JSON.parse(this.jsonString);
    let i=0;
    while(this.bookListTemp[i]){
      if(this.bookListTemp[i][colName].toString().toLowerCase().indexOf(filterValue.toLowerCase())<0)
      {
        this.bookListTemp.splice(i,1);
      }
      else
        i++;
    }
  }
}
